<?php

    if(isset($_POST["btnSubmit"]))
    {
        if($_POST["txtName"]=="abc" && $_POST["txtPassword"]=="abc123")
        {
            echo "Welcome". $_POST["txtName"];
        }
        else
        {
            
            header("location:login_page.html");
        }
        echo "Invalid username or password";
    }
    else
    {
        header("location:register_page.html");
    }


?>