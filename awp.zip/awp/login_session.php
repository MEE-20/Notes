<?php
if(isset($_POST["btnLogin"]))
{
    if($_POST["txtName"]=="abc" && $_POST["txtPassword"]=="abc123")
    {
        session_start();
        $_SESSION["uName"] = $_POST["txtName"];
        header("location:list_session.php");
    }
    else{
        echo "<br> Invalid username or password";
    }

}
else
{
    echo "<b> Login Here </b>";
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login Page</title>
</head>
<body>
    <form action="login_session.php" method="POST">
    Name : <input type="text" name="txtName" id="txtName" required="required"> <br>
    Password : <input type="password" name="txtPassword" id="txtPassword" required="required"> <br>
    <input type="submit" value="Log in" name="btnLogin" id="btnLogin">
</form>
</body>
</html>