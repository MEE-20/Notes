function validation()
        {
           // alert("aa");
            //1. Check if empty
            var isNameEmpty = isempty("name","errName","Name Cannot be Empty");
            var isAgeEmpty = isempty("age","errAge","Age Cannot be Empty");
            var isEmailEmpty = isempty("email","errEmail","Email cannot be empty");
            var isPassEmpty = isempty("password","errPass","Password cannot be empty");
            if(isNameEmpty == false)
            {
                validateName("name","errName","Name Cannot have number");
            }
            if(isAgeEmpty == false)
            {
               var isAgeNum =  validatenumber("age","errAge","Age Can have only number");
                if(isAgeNum == true)
                {
                    AgeinRange("age","errAge","Age not in Range",18,90);
                }
            }
            if(isEmailEmpty == false)
            {
                validateEmail("email","errEmail","invalid email");
            }
            if(isPassEmpty == false)
            {
                var isConPassEmpty = isempty("ConfirmPass","errConPass","Please Confirm Your Password")
                if(isConPassEmpty == false)
                {
                    validatePass("password","errPass","ConfirmPass","errConPass","Passowrd does not match");
                 }
            }
        }
        function isempty(fieldID,errID,errMsg)
        {
            var ele = document.getElementById(fieldID);
            var errDiv = document.getElementById(errID);
            if(ele.value == "")
            {
                errDiv.innerHTML = errMsg;
                return true;
            }
            else
            {
                errDiv.innerHTML = "";
                return false;
            }
        }
        function validateName(fieldID,errID,errMsg)
        {
            var ele = document.getElementById(fieldID);
            var errDiv = document.getElementById(errID);
            if(!isNaN(ele.value))
            {
                errDiv.innerHTML=errMsg;
                return false;
            }
            else
            {
                errDiv.innerHTML="";
                return true;
            }
        }
        function validatenumber(fieldID,errID,errMsg)
        {
            var ele = document.getElementById(fieldID);
            var errDiv = document.getElementById(errID);
            if(isNaN(ele.value))
            {
                errDiv.innerHTML=errMsg;
                return false;
            }
            else
            {
                errDiv.innerHTML="";
                return true;
            }
        }
        function AgeinRange(fieldID,errID,errMsg,min,max)
        {
            var ele = document.getElementById(fieldID);
            var errDiv = document.getElementById(errID);

            if(ele.value >= min && ele.value <= max)
            {
                errDiv.innerHTML = "";
                return true;
            }   
            else
            {
                errDiv.innerHTML = errMsg;
                return false;
            }
        }
        function validatePass(fieldID,errID,fieldID2,errID2,errMsg)
        {
            var ele1 = document.getElementById(fieldID);
            var ele2 = document.getElementById(fieldID2);
            var errDiv1 = document.getElementById(errID);
            var errDiv2 = document.getElementById(errID2);
            if(ele1.value == ele2.value)
            {
                errDiv1.innerHTML = "";
                errDiv2.innerHTML = "";
                return false;
            }
            else
            {
                errDiv1.innerHTML = "";
                errDiv2.innerHTML = errMsg;
                return true;
            }
        }
        function validateEmail(fieldID,errID,errMsg)
        {
            var ele = document.getElementById(fieldID);
            var errDiv = document.getElementById(errID);

            if(! /@/.test(ele.value))
            {
                errDiv.innerHTML = errMsg;
                return false;
            }
            else
            {
                errDiv.innerHTML = "";
                return true;
            }

        }