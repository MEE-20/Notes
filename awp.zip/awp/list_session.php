<?php
        session_start();
        if(!isset($_SESSION["uName"]))
        {
            header("location:login_session.php");
        }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>list</title>
    <link rel="stylesheet" href="bootstrap.css">
    <script src="jquery-3.4.1.min.js"></script>
    <script src="bootstrap.js"></script>
</head>
<body>
    <h1>
        Welcome <?php echo $_SESSION["uName"]; ?>
    </h1>
    <a href="logout_session.php"> Log Out</a> <br>
    <a href="AddRecord_session.php">Add New Record</a> <br>
    <table class="table">
        <?php
                $refToConnection = mysqli_connect("localhost","dac","dac","PHP");

                $resultSet = mysqli_query($refToConnection, "select * from EMP");

                while($currRow=mysqli_fetch_row($resultSet))
                {
                    echo "<tr>".
                        "<td>".$currRow[0]."</td>".
                        "<td>".$currRow[1]."</td>".
                        "<td>".$currRow[2]."</td>"."</tr>";
                       // "<td>"."<a href=''></a>"."</td>".
                }
                mysqli_close($refToConnection);
        ?>
    </table>
    
</body>
</html>