<?php

        if(!empty($_POST["txtName"]))
        {
            echo "Welcome".$_POST["txtName"];
        }
        else
        {
            header("location:register.html");
        }

?>