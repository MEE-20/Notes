<?php
        session_start();
        if(!isset($_SESSION["uName"]))
        {
            header("location:login_session.php");
        }
        else
        {
            //echo "before if 1 <br>";
            if(isset($_POST["btnRecord"]))
            {
                //echo "in if 1 <br>";
                $refToConnect = mysqli_connect("localhost","dac","dac","PHP");
               // echo "1<br>";
                $query = "insert into EMP values(". 
                          $_POST["numEmp"].",'". 
                          $_POST["txtEName"]."',". 
                          $_POST["numSal"].")";
                          echo $query;

                //echo "2<br>";
                $resultSet = mysqli_query($refToConnect,$query);
                $RowsAffected = mysqli_affected_rows($refToConnect);
                
                echo $RowsAffected;
                 echo "<br>";
                if($RowsAffected>0)
                {
                    echo "Data Added <br>";
                }
                else{
                    echo " Something went Wrong <br>";
                }
            }
            else{
                echo "Please enter data<br>";
            }
        }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add Record</title>
</head>
<body>
    <form action="AddRecord_session.php" method="POST">
    <a href="list_session.php">Go back to List</a> <br> <br>
        Employee no. <input type="number" name="numEmp"> <br> <br>
        Name <input type="text" name="txtEName"> <br> <br>
        Salary <input type="number" name="numSal"> <br> <br>
        <input type="submit" value="Add Record" name="btnRecord"> <br> <br>
    </form>
</body>
</html>