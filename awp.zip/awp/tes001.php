<?php 
        echo "<b> hello </b>";

        $a = 100;
        $b = 200;
        $c = $a + $b;

        echo "<br> $c <br>";
        echo $a.$b;

?>