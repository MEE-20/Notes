<?php 

session_start();
    if(!isset($_SESSION["userName"])){
        header("location:050PuneDemo.php");
    }
    else
    {
        if(isset($_GET["ENo"]))
        {
            $enoToBedeleted = $_GET["ENo"];
            $refToConnection=       
                        mysqli_connect("localhost","root"
                    ,"manager","AWP");
            $query = 
                "delete from Emp where ENo= ".$enoToBedeleted;

            mysqli_query($refToConnection,$query);

            mysqli_close($refToConnection);
            header("location:051PuneDemo.php");
        }
        else
        {
            header("location:051PuneDemo.php");
        }
}
?>