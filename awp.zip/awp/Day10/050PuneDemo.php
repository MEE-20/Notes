<?php 
    if(isset($_POST["btnLogin"]))
        {
            //Check UserName and Password
            if($_POST["txtName"]=="abc" && $_POST["txtPassword"]=="abc@123")
            {
                 session_start();
                 $_SESSION["userName"] = $_POST["txtName"];
                 header("location:051PuneDemo.php");       
            }
            else
            {
                echo "UserName / password is incorrect";
            }
        }
    else
    {
        echo "Login Here";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
</head>
<body>
    <form action="050PuneDemo.php" method="POST">
        UName: <input type="text" name="txtName" id="txtName"><br>
        Password: <input type="password" name="txtPassword" id="txtPassword"><br>
        <input type="submit" value ="Login" name="btnLogin" id="btnLogin">
    </form>
</body>
</html>