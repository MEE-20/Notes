$(document).ready(function(){
    debugger;
    var n1;
    var c1;
    var p1;
    $('#btnAdd').click(function(){
        
        if($('#txtName').val()=="")
        {
            $('#txtName').attr("placeholder","name can't be empty");
	}
        if($('#txtCuisine').val()=="")
        {
            $('#txtCuisine').attr("placeholder","Cuisine can't be empty");
	}
        if($('#numPrice').val()=="")
        {
            $('#numPrice').attr("placeholder","Price can't be empty");
        }
        else
        {
            debugger;
            var n = $('#txtName').val();
            var c = $('#txtCuisine').val();
            var p = $('#numPrice').val();

            var row = '<tr><td>'+n+
                      '</td><td>'+c+
                      '</td><td>'+p+
                      '</td><td>'+
                      '<input type="button" value="Edit" id="btnEdit">'+
                      '<input type="button" value="Save" id="btnSave">'+
                      '<input type="button" value="Delete" id="btnDelete">'+
                      '</td></tr>';
            $('#recTable').append(row);
            $($($(this).parent().parent().children()[0]).children()).val("");
            $($($(this).parent().parent().children()[1]).children()).val("");
            $($($(this).parent().parent().children()[2]).children()).val("");
        }
    });
        $('#btnEdit').live("click",function(){
            debugger;
            n1 = $($(this).parent().parent().children()[0]).html();
            c1 = $($(this).parent().parent().children()[1]).html();
            p1 = $($(this).parent().parent().children()[2]).html();
            var obj1 = $($(this).parent().parent().children()[0]);
            var obj2 = $($(this).parent().parent().children()[1]);
            var obj3 = $($(this).parent().parent().children()[2]);
		var val1 ="<input type='text' value="+n1+">";
		var val2 ="<input type='text' value="+c1+">";
		var val3 ="<input type='text' value="+p1+">";
            obj1.html(val1);
            obj2.html(val2);
            obj3.html(val3);
            $(this).css("opacity",0);
           // $(this).unbind("click");

        });
        $('#btnSave').live("click",function(){
            debugger;
            var new1 = $($($(this).parent().parent().children()[0]).children()).val(); //alert(new1);
            var new2 = $($($(this).parent().parent().children()[1]).children()).val();
            var new3 = $($($(this).parent().parent().children()[2]).children()).val();
            var obj1 = $($(this).parent().parent().children()[0]);
            var obj2 = $($(this).parent().parent().children()[1]);
            var obj3 = $($(this).parent().parent().children()[2]);

            $($(this).parent().children()[0]).css("opacity",1);

            obj1.html(new1);
            obj2.html(new2);
            obj3.html(new3);

        });
    //});
        $('#btnDelete').live("click",function(){
            debugger;
                $($(this).parent().parent()).remove();
        });
   // });   
});
