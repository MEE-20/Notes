package linkedlist;

import java.util.Scanner;

public class Program {
	static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
		int choice;
		list l = new list();
		
		while((choice=Program.menulist()) != 0 )
		{
			switch(choice)
			{
				case 1: System.out.println("Enter Data : ");
						l.addFirst(sc.nextInt());
						break;
				case 2: if(l.isEmpty())
							System.out.println("List is Empty !!! ");
						else
							l.print();
						break;
				case 3:	if(l.isEmpty())
							System.out.println("List is Empty !!! ");
						else
							l.deleteFirst();		
			}
		}
	}

	private static int menulist() {
		System.out.println("======= Singly Linear Linked List =======");
		System.out.println("0. Exit");
		System.out.println("1. Add First ");
		System.out.println("2. Print list ");
		System.out.println("3. Delete First ");
		System.out.print("Enetr Your Choice  : ");
		return sc.nextInt();
	}

}
