package linkedlist;

class list {
	Node head;

	public list() {
		//head = null;
	}
	public boolean isEmpty()
	{
		return head == null;
	}
	public void addFirst(int data)
	{
		Node nptr = new Node(data);
		if(isEmpty())
			head = nptr;
		else
		{
			Node trav = head;
			head = nptr;
			nptr.next=trav;
		}
	}
	public void print()
	{
		Node trav = head;
		System.out.print(" Head --> ");
		do
		{
			System.out.print(trav.data+" -- > ");
			trav=trav.next;
			
		}while(trav != null);
		System.out.println(" Null ");
	}
	public void deleteFirst()
	{
		Node trav = head;
		head = head.next;
		trav=null;
	}

}
