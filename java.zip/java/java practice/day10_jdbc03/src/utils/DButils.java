package utils;

import java.sql.Connection;
import java.sql.DriverManager;

public class DButils {
	public static final String DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String URL = "jdbc:mysql://localhost:3306/sales";
	public static final String USER = "dac";
	public static final String PASSWORD = "dac";
		public static Connection getConnection( ) throws Exception
		{
			Class.forName(DRIVER);
			return DriverManager.getConnection(URL, USER, PASSWORD);
		}
}
