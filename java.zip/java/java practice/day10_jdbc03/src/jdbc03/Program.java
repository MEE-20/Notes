package jdbc03;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import pojo.Customer;
import utils.DButils;

public class Program {
	static Statement st = null;
	static Connection con = null;
	
	public static void main(String[] args)  {
		try {
			con = DButils.getConnection();
			st = con.createStatement();
			String sql = "SELECT * FROM CUSTOMERS";
			try(ResultSet rs = st.executeQuery(sql);)
			{
				System.out.printf("cnum \t cname \t\t    city \t rating    snum \n");
				System.out.println("-----------------------------------------------------------");
				while(rs.next())
				{
					Customer cus = new Customer();
					cus.setCnum(rs.getInt("cnum"));
					cus.setCname(rs.getString(2));
					cus.setCity(rs.getString(3));
					cus.setRating(rs.getInt("rating"));
					cus.setSnum(rs.getInt(5));
					System.out.println(cus.toString());
				}
			}
	
		} 
		catch (Exception e) {

			e.printStackTrace();
		}
		finally
		{
			try {
				if(st != null)
					st.close();
				if(con != null)
					con.close();
			} 
			catch (SQLException e) {
				
				e.printStackTrace();
			}
		}

		
	}

}
