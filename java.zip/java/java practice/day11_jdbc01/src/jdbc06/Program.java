package jdbc06;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import utils.DButils;

public class Program {

	public static void main(String[] args) {
		try(Connection con = DButils.getConnection();
				Statement st = con.createStatement();)
		{
			String sql = "INSERT INTO CUSTOMERS VALUES(2010,'Priyanka','Bhilai',100,1007)";
			int count = st.executeUpdate(sql);
			System.out.println(count+" rows affected ");
		} 
		catch (Exception e) {
			
			e.printStackTrace();
		} 

	}

}
