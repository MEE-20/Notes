class Inout
{
    public static void main(String[] args)
    {
        int empid=101;
        String name="meenal";
        double salary=1200000.00;
        //float sal=200000.00f;
        System.out.printf(" %-6d %-10s %f \n ",empid,name,salary);
    }
}