package day4_instanceCount;
class Count
{
	public static int cnt;
	public Count() 
	{
		cnt++;
	}
	public static int getCnt() 
	{
		return cnt;
	}
}
public class Counter 
{
	public static void main(String[] args) 
	{
		System.out.println(Count.getCnt());
		Count c1 = new Count();
		System.out.println(Count.getCnt());
		Count c2 = new Count();
		System.out.println(Count.getCnt());
		Count c3 = new Count();
		System.out.println(Count.getCnt());
	}
}
