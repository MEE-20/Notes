package jdbc02;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import pojo.Customer;

public class Program {
	static Connection con = null;
	static Statement st = null;
	public static void main(String[] args) {
		try {
			Driver d = new com.mysql.cj.jdbc.Driver();
			DriverManager.registerDriver(d);
			
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sales","dac","dac");
			
			st = con.createStatement();
			
			String sql = "SELECT * FROM CUSTOMERS";
				try(ResultSet rs = st.executeQuery(sql);)
				{
					System.out.printf("cnum \t cname \t\t    city \t rating    snum \n");
					System.out.println("-----------------------------------------------------------");
					while(rs.next())
					{
						Customer cus = new Customer();
						cus.setCnum(rs.getInt("cnum"));
						cus.setCname(rs.getString(2));
						cus.setCity(rs.getString(3));
						cus.setRating(rs.getInt("rating"));
						cus.setSnum(rs.getInt(5));
						System.out.println(cus.toString());
					}
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			
			} 
			catch (SQLException e) {
			
					e.printStackTrace();
			}
			finally
			{
				try {
					if(st != null)
						st.close();
					if(con != null)
						con.close();
				} 
				catch (SQLException e) {
					
					e.printStackTrace();
				}
			}

	}

}
