package test;

import java.util.Comparator;

public class sortByRollNo implements Comparator<Student> {

	@Override
	public int compare(Student arg0, Student arg1) {
		
		return arg0.rollNo - arg1.rollNo;
	}

}
