package test;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

class Student
{
	int rollNo;
	String name;
	float marks;
	public Student() {
		this(0,"",0);
	}
	public Student(int rollNo, String name, float marks) {
		this.rollNo = rollNo;
		this.name = name;
		this.marks = marks;
	}
	
	public int getRollNo() {
		return rollNo;
	}
	public String getName() {
		return name;
	}
	public float getMarks() {
		return marks;
	}
	@Override
	public String toString() {
		return "Student      rollNo=" + rollNo + ", Name=" + name + ", marks=" + marks;
	}
}
public class Program {
	
	static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) 
	{
		Student[] stu = Program.getStudent();
		Program.printStudent(stu);
		
		Comparator<Student> c = null;
		
		c = new sortByRollNo();
		Arrays.sort(stu, c);
		Program.printStudent(stu);
		
		c = new sortByName();
		Arrays.sort(stu, c);
		Program.printStudent(stu);
		
		c = new sortByMarks();
		Arrays.sort(stu, c);
		Program.printStudent(stu);
	}

	private static void printStudent(Student[] stu) {
		if(stu != null)
			for(Student s : stu )
			System.out.println(s.toString());
		System.out.println();
		
	}

	private static Student[] getStudent() {
		Student[] stu = new Student[3];
		int rn;
		String n=null;
		float mrk;
		System.out.println("Enter Student Details : ");
				for(int i=0; i<3; i++)
				{
					System.out.print("Roll No.     : ");
					rn = sc.nextInt();
					sc.nextLine();
					System.out.print("   Name      : ");
					n = sc.nextLine();
					System.out.print("  Marks    : ");
					mrk = sc.nextFloat();
					
					stu[i] = new Student(rn,n,mrk);
				}
		return stu;
	}

}
