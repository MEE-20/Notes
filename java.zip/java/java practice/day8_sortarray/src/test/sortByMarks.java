package test;

import java.util.Comparator;

public class sortByMarks implements Comparator<Student> {

	@Override
	public int compare(Student o1, Student o2) {
		return (int) (o1.marks - o2.marks);
	}

}
