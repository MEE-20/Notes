package typewidth;

public class Width {

	public static void main(String[] args) {
		//  int i = 9348.39; // invalid
		String s = "9348.39";
		int i = Integer.parseInt(s);
		System.out.println(i);
		System.out.println("size of int : "+ (Integer.SIZE/8)+" bytes");
		
		// long int li; // does not support long int 
		short sh = (short) 80999;
		System.out.println(sh);
		
		byte b = (byte) 129;
		System.out.println(b);
		
		float f = (float) 218.938;
		double d = 2930.3f;
		char c = (char) -3;
		// boolean bl = 0; even if we store '0' as string and use valueOf(String s)
		// it will allocate 'true' in boolean value, it will set 'false' only if 
		// string will have 'null'

	}

}
