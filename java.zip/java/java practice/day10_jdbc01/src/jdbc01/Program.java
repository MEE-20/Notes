package jdbc01;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Program {

	static Connection con = null;
	static Statement st = null;
	public static void main(String[] args) {
		
			try {
				//Load and register driver
				Driver d = new com.mysql.cj.jdbc.Driver();
				DriverManager.registerDriver(d);
				
				//Connect using user credential
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sales", "dac", "dac");
				
				//create statement object
				st = con.createStatement();
				
				//prepare and execute query
				String sql = "SELECT * FROM CUSTOMERS";
				try(ResultSet rs = st.executeQuery(sql);)
				{
					while(rs.next())
					{
						int cnum = rs.getInt(1);
						String cname = rs.getString(2);
						String city = rs.getString("city");
						int rating = rs.getInt("rating");
						int snum = rs.getInt("snum");
						System.out.printf("%-8d%-20s%-20s%-8d%-5d\n",cnum,cname,city,rating,snum);
					}
				}
				
			} 
			catch (SQLException e) {
				
				e.printStackTrace();
			}
			finally
			{
				try {
					if(st != null)
						st.close();
					if(con != null)
						con.close();
				} 
				catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
	}

}
