import p2.Employee;
class Program 
{

	public static void main(String[] args) 
	{
		Employee e1 = new Employee();
		System.out.println(e1.toString());

	}

}
