package p1;

public class Person 
{
	@Override
	public String toString()
	{
		return "Perosn.toString()";
	}
}
