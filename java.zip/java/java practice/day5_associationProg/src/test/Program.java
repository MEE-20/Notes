package test;

import java.util.Scanner;

public class Program {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

		/*Date d = new Date();
		Program.acceptRecord(d);
		Program.printRecord(d);
		
		Address addr = new Address();
		Program.acceptRecord(addr);
		Program.printRecord(addr);*/
		
		Person p = new Person();
		Program.acceptRecord(p);
		Program.printRecord(p);

	}

	private static void printRecord(Address addr) {
		System.out.println(addr.toString());
		
	}

	private static void acceptRecord(Address addr) {
		System.out.println("\n Address");
		System.out.print("City    : ");
		addr.setCity(sc.nextLine());
		//sc.nextLine();
		System.out.println("State     : ");
		addr.setState(sc.nextLine());
		//sc.nextLine();
		System.out.println("Pin Code    : ");
		addr.setPincode(sc.nextInt());
		
	}

	private static void printRecord(Person p) {
		//System.out.println(p.toString());
		System.out.println(" ********* Person *********");
		System.out.println(" Name    : "+p.getName());
		System.out.println(" DOB     : "+p.getDob());
		System.out.println(" Address : "+p.getAddr());
		
	}

	private static void acceptRecord(Person p) {
		System.out.println("Person");
		System.out.println("Name    : ");
		p.setName(sc.nextLine());
		Date dob = p.getDob();
		Program.acceptRecord(dob);
		sc.nextLine();
		Address addr = p.getAddr();
		Program.acceptRecord(addr);
		
	}

	private static void printRecord(Date d) {
		System.out.println(d.toString());
		
	}

	private static void acceptRecord(Date d) {
		System.out.println("Date of birth");
		System.out.print("Date    : ");
		d.setDay(sc.nextInt());
		System.out.print("Month   : ");
		d.setMonth(sc.nextInt());
		System.out.print("Year    : ");
		d.setYear(sc.nextInt());
		
	}

}

