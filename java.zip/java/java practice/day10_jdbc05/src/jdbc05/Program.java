package jdbc05;

import java.io.IOException;
import java.util.List;

import dao.CustomerDao;
import pojo.Customer;

public class Program {

	public static void main(String[] args) {
		
		try(CustomerDao cusdao = new CustomerDao();)
		{
			Customer cus = new Customer(2005,"Priyanka","London",300,1007);
			System.out.println(cusdao.insertValue(cus));
			
			System.out.println(cusdao.updateValue(2008, 300));
			
			System.out.println(cusdao.deleteRow(2005));
			
			List<Customer> cList = cusdao.getCustomer();
			System.out.printf("cnum \t cname \t\t    city \t rating    snum \n");
			System.out.println("-----------------------------------------------------------");
			for (Customer customer : cList) 
			{
				System.out.println(customer.toString());
			}
			
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		

	}

}
