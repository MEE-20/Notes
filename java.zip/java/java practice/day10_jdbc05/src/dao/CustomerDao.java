package dao;


import java.io.Closeable;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import pojo.Customer;
import utils.DButils;

public class CustomerDao implements Closeable
{

	private Connection con;
	private Statement st;
	
	public CustomerDao() throws Exception {
		con = DButils.getConnection();
		st = con.createStatement();
	}
	
	public int insertValue(Customer cus) throws Exception
	{
		String sql = "INSERT INTO CUSTOMERS VALUES("+cus.getCnum()+",'"+cus.getCname()+"','"+cus.getCity()+"',"+cus.getRating()+","+cus.getSnum()+")";
		return st.executeUpdate(sql);
	}
	
	public int updateValue(int cnum, int rating) throws Exception
	{
		String sql = "UPDATE CUSTOMERS SET rating="+rating+" WHERE cnum="+cnum+"";
		return st.executeUpdate(sql);
	}
	
	public int deleteRow(int cnum) throws Exception
	{
		String sql = "DELETE FROM CUSTOMERS WHERE cnum="+cnum+"";
		return st.executeUpdate(sql);
	}
	
	public List<Customer> getCustomer() throws Exception
	{
		List<Customer> cusList = new ArrayList<Customer>();
		String sql = "SELECT * FROM CUSTOMERS";
		try(ResultSet rs = st.executeQuery(sql);)
		{
			while(rs.next())
			{
				Customer cus = new Customer();
				cus.setCnum(rs.getInt("cnum"));
				cus.setCname(rs.getString(2));
				cus.setCity(rs.getString(3));
				cus.setRating(rs.getInt("rating"));
				cus.setSnum(rs.getInt(5));
				cusList.add(cus);
			}
		}
		return cusList;
	}

	@Override
	public void close() throws IOException {
		try {
			if(st != null)
				st.close();
			if(con != null)
				con.close();
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}
	
}
