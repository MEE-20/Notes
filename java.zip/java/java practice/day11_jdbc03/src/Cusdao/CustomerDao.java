package Cusdao;

import java.io.Closeable;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import pojo.Customer;
import utils.DButils;

public class CustomerDao implements Closeable {
	
	private Connection con;
	private CallableStatement insertSt;
	private CallableStatement updateSt;
	private CallableStatement deleteSt;
	private CallableStatement selectSt;
	
	public CustomerDao() throws Exception {
		con = DButils.getConnection();
		insertSt = con.prepareCall("{call sp_insert(?,?,?,?,?)}");
		updateSt = con.prepareCall("{call sp_update(?,?)}");
		deleteSt = con.prepareCall("{call sp_delete(?)}");
		selectSt = con.prepareCall("{call sp_select()}");
	}
	
	public boolean insert(Customer cus) throws Exception
	{
		insertSt.setInt(1, cus.getCnum());
		insertSt.setString(2, cus.getCname());
		insertSt.setString(3, cus.getCity());
		insertSt.setInt(4, cus.getRating());
		insertSt.setInt(5, cus.getSnum());
		return insertSt.execute();
	}
	
	public boolean update(int cnum, int rating) throws Exception
	{
		updateSt.setInt(1, cnum);
		updateSt.setInt(2, rating);
		return updateSt.execute();
	}

	public boolean delete(int cnum) throws Exception
	{
		deleteSt.setInt(1, cnum);
		return deleteSt.execute();
	}
	
	public List<Customer> select() throws Exception
	{
		List<Customer> cList = new ArrayList<>();
		selectSt.execute();
		try(ResultSet rs = selectSt.getResultSet();)
		{
			while(rs.next())
			{
				Customer cus = new Customer(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5));
				cList.add(cus);
			}
		}
		return cList;
	}
	@Override
	public void close() throws IOException {
		try {
			con.close();
			insertSt.close();
			updateSt.close();
			deleteSt.close();
			selectSt.close();
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}
}
