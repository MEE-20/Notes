package jdbc08;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import Cusdao.CustomerDao;
import pojo.Customer;

public class Program {
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		try(CustomerDao dao = new CustomerDao();)
		{
			int choice, cnum, rating;
			while((choice = menuList()) != 0)
			{
				switch(choice)
				{
					case 1: Customer cus = new Customer();
							Program.acceptRecord(cus);
							dao.insert(cus);
							break;
					case 2: System.out.print("Enter Customer number : ");
							cnum = sc.nextInt();
							System.out.println("Enter New Rating : ");
							rating = sc.nextInt();
							dao.update(cnum, rating);
							break;
					case 3: System.out.print("Enter customer number : ");
							cnum = sc.nextInt();
							dao.delete(cnum);
							break;
					case 4: List<Customer> cList = dao.select();
							Program.printRecord(cList);
				}
			}
		} 
		catch (IOException e) {
			
			e.printStackTrace();
		} 
		catch (Exception e) {
			
			e.printStackTrace();
		}
		
		
	}
	private static void printRecord(List<Customer> cList) {
		if(cList != null)
			for(Customer cus : cList)
				System.out.println(cus.toString());
		
	}
	private static void acceptRecord(Customer cus) {
		System.out.print("Enetr Customer Number : ");
		cus.setCnum(sc.nextInt());
		sc.nextLine();
		System.out.print("Enter Customer Name : ");
		cus.setCname(sc.nextLine());
		System.out.print("Enter City : ");
		cus.setCity(sc.nextLine());
		System.out.print("Enter Rating : ");
		cus.setRating(sc.nextInt());
		System.out.print("Enter Sales num : ");
		cus.setSnum(sc.nextInt());
		
	}
	private static int menuList() {
		System.out.println("============================================ ");
		System.out.println("0. Exit");
		System.out.println("1. Insert");
		System.out.println("2. Update");
		System.out.println("3. Delete");
		System.out.println("4. Select");
		System.out.print("Enter your choice : ");
		return sc.nextInt();
	}
}
