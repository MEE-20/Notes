package test;

public class Person {
	private String name;
	private Date dob;
	private Address addr;
	public Person() {
		name = "";
		dob = new Date();
		addr = new Address();
	}
	public Person(String name, Date dob, Address addr) {
		super();
		this.name = name;
		this.dob = dob;
		this.addr = addr;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public Address getAddr() {
		return addr;
	}
	public void setAddr(Address addr) {
		this.addr = addr;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", dob=" + dob + ", addr=" + addr + "]";
	}
	
	
	
	
}
