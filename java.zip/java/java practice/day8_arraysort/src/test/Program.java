package test;

import java.util.Arrays;
import java.util.Scanner;

class Student implements Comparable<Student>
{
	int rollNo;
	String name;
	float marks;
	public Student() {
		this(0,"",0);
	}
	public Student(int rollNo, String name, float marks) {
		this.rollNo = rollNo;
		this.name = name;
		this.marks = marks;
	}
	@Override
	public String toString() {
		return "Student      rollNo=" + rollNo + ", Name=" + name + ", marks=" + marks;
	}
	@Override
	public int compareTo(Student arg) {
		
		return name.compareTo(arg.name);
	}
	
}
public class Program {
	static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) 
	{
		Student[] stu = Program.getStudent();
		Program.printStudent(stu);
		
		Arrays.sort(stu);
		Program.printStudent(stu);
	}

	private static void printStudent(Student[] stu) {
		if(stu != null)
			for(Student s : stu )
			System.out.println(s.toString());
		System.out.println();
		
	}

	private static Student[] getStudent() {
		Student[] stu = new Student[3];
		int rn;
		String n=null;
		float mrk;
		System.out.println("Enter Student Details : ");
				for(int i=0; i<3; i++)
				{
					System.out.print("Roll No.     : ");
					rn = sc.nextInt();
					sc.nextLine();
					System.out.print("   Name      : ");
					n = sc.nextLine();
					System.out.print("  Marks    : ");
					mrk = sc.nextFloat();
					
					stu[i] = new Student(rn,n,mrk);
				}
		return stu;
	}

	/*
	 * public static void main(String[] args) { int[] arr = new int[] {5,4,7,9,1,3};
	 * System.out.println(Arrays.toString(arr)); Arrays.sort(arr);
	 * System.out.println(Arrays.toString(arr));
	 * 
	 * }
	 */

}
