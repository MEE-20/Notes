package test;

@SuppressWarnings("serial")
public class StackOverflowException extends Exception {

	public StackOverflowException(String string) {
		super(string);
	}

}
