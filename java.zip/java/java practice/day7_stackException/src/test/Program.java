package test;

import java.util.Scanner;

public class Program {
	static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
		int choice;
		int[] ele = new int[1];
		Stack st = new Stack();
		while((choice = Program.menulist()) != 0)
		{
			try {
				switch(choice)
				{
					case 1: Program.acceptEle(ele);
							st.push(ele[0]);
							break;
					case 2: ele[0] = st.peek();
							Program.printEle(ele);
							st.pop();
							break;		
				}
			} 
			catch (StackOverflowException | StackEmptyException e) {
				System.out.println(e.getMessage());
			}
		}
	}
	private static void printEle(int[] ele) {
		System.out.println("Top has : "+ele[0]);
		
	}
	private static void acceptEle(int[] ele) {
		System.out.print("Enter element to stack   : ");
		ele[0]=sc.nextInt();
		
	}
	private static int menulist() {
		System.out.println("======== STACK ========");
		System.out.println("0. Exit");
		System.out.println("1. Push");
		System.out.println("2. Pop");
		System.out.print("Enter Your choice    : ");
		return sc.nextInt();
	}
}
