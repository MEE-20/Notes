package test;

@SuppressWarnings("serial")
public class StackEmptyException extends Exception {


	public StackEmptyException(String string) {
		super(string);
	}

}
