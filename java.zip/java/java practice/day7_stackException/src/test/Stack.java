package test;

public class Stack {
	int top = -1;
	int[] arr;
	public Stack() {
		this(5);
	}
	public Stack(int size) {
		
		this.arr = new int [size];
	}
	public boolean empty()
	{
		return top == -1;
	}
	public boolean full()
	{
		return top == arr.length - 1;
	}
	public void push(int ele) throws StackOverflowException
	{
		if(full())
			throw new StackOverflowException("Stack is full");
		arr[++top]=ele;
	}
	public int peek() throws StackEmptyException
	{
		if(empty())
			throw new StackEmptyException("Stack is Empty");
		return arr[top];
	}
	public void pop() throws StackEmptyException
	{
		if(empty())
			throw new StackEmptyException("Stack is Empty");
		top--;
	}
}
