package shape;
class Shape
{
	protected float area;

	public Shape() {
		
	}

	public float getArea() {
		return area;
	}	
}

class Rectangle extends Shape
{
	private int length;
	private int bredth;
	public Rectangle() {
	}
	public void setLength(int length) {
		this.length = length;
	}
	public void setBredth(int bredth) {
		this.bredth = bredth;
	}
	public void calculateArea()
	{
		 area = length * bredth;
	}
	
}
class Circle extends Shape
{
	private int radius;

	public Circle() {
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}
	public void calculateArea()
	{
		area = (float) (Math.PI * (Math.pow(radius, 2)));
	}
	
}
public class Program {

	public static void main(String[] args) {
		
		Rectangle rt = new Rectangle();
		rt.setBredth(3);
		rt.setLength(6);
		rt.calculateArea();
		System.out.println("Area of Rectangle   : "+rt.getArea());
		
		Circle c = new Circle();
		c.setRadius(3);
		c.calculateArea();
		System.out.println("Area of Circle   : "+c.getArea());

	}

}
