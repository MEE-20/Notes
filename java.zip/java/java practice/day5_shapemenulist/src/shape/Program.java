package shape;

import java.util.Scanner;

abstract class Shape
{
	protected float area;

	public Shape() {
		
	}
	public abstract void calculateArea();
	public float getArea() {
		return area;
	}	
}

class Rectangle extends Shape
{
	private int length;
	private int bredth;
	public Rectangle() {
	}
	public void setLength(int length) {
		this.length = length;
	}
	public void setBredth(int bredth) {
		this.bredth = bredth;
	}
	public void calculateArea()
	{
		 area = length * bredth;
	}
	
}
class Circle extends Shape
{
	private int radius;

	public Circle() {
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}
	public void calculateArea()
	{
		area = (float) (Math.PI * (Math.pow(radius, 2)));
	}
	
}
public class Program {
	static Scanner sc = new Scanner(System.in);
	
	private static int menulist() {
		System.out.println("0. Exti");
		System.out.println("1. Area of Rectangle");
		System.out.println("2. Area of Circle");
		System.out.println("Enter your choice : ");
		return sc.nextInt();
	}
	
	public static void main(String[] args) {
		int choice;
		while((choice = Program.menulist()) != 0)
		{
			Shape sh = null;
			switch(choice)
			{
				case 1: sh = new Rectangle();
						break;
				case 2: sh = new Circle();
						break;
			}
			if(sh != null)
			{
				Program.acceptRecord(sh);
				sh.calculateArea();
				Program.printRecord(sh);
			}
			
		}
	}

	private static void printRecord(Shape sh) {
		System.out.println("Area   : "+sh.getArea());
		
	}

	private static void acceptRecord(Shape sh) {
		if(sh instanceof Rectangle)
		{
			Rectangle rect = (Rectangle) sh;
			System.out.print("Enter Length : ");
			rect.setLength(sc.nextInt());
			System.out.print("Enter Bredth : ");
			rect.setBredth(sc.nextInt());
		}
		else
		{
			Circle c = (Circle) sh;
			System.out.println("Enter Radius : ");
			c.setRadius(sc.nextInt());
		}
	}

}
