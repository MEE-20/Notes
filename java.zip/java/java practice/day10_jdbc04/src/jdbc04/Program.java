package jdbc04;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import pojo.Customer;
import utils.DButils;

public class Program {
	
	public static void main(String[] args) {
		try(Connection con = DButils.getConnection();
				Statement st = con.createStatement(); )
		{
			String sql = "SELECT * FROM CUSTOMERS";
			try(ResultSet rs = st.executeQuery(sql);)
			{
				System.out.printf("cnum \t cname \t\t    city \t rating    snum \n");
				System.out.println("-----------------------------------------------------------");
				while(rs.next())
				{
					Customer cus = new Customer(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5));
					System.out.println(cus.toString());
					
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

}
