package utils;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DButils {
	public static Connection getConnection( ) throws Exception
	{
		InputStream in = new FileInputStream("config.properties");
		Properties p = new Properties();
		p.load(in);
		
		Class.forName(p.getProperty("DRIVER"));
		return DriverManager.getConnection(p.getProperty("URL"), p.getProperty("USER"), p.getProperty("PASSWORD"));
	}
}
