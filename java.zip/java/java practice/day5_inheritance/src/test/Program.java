package test;

class Person
{
	private String name;
	private int age;
	
	public Person() {
		System.out.println("public Person()");
		name = "";
		age = 0;
	}
	public Person(String name, int age) {
		System.out.println("public Person(String name, int age)");
		this.name = name;
		this.age = age;
	}
	public void showRecord() {
		
		System.out.println("Name    : "+name);
		System.out.println("Age     : "+age);
	}
	
}

class Employees extends Person
{
	private int empid;
	private float salary;
	public Employees() {
		System.out.println("public Employees()");
		empid = 0;
		salary = 0;
	}
	public Employees(String name, int age, int empid, float salary) {
		super(name, age);
		System.out.println("public Employees(String name, int age, int empid, float salary)");
		this.empid = empid;
		this.salary = salary;
	}
	public void printRecord()
	{
		super.showRecord();
		System.out.println("Emp id    : "+empid);
		System.out.println("Salary    : "+salary);
	}
	
}
public class Program 
{

	public static void main(String[] args) {
		
		Employees emp = new Employees("meenal", 24, 1243, 60000);
		emp.printRecord();
		
		System.out.println("\n Upcasting");
		Person p = emp;
		p.showRecord();
		
		System.out.println("\n Downcasting");
		Employees emp2 = (Employees) p;
		emp2.printRecord();
	}

}
