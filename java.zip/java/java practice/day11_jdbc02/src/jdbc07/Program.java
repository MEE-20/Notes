package jdbc07;


import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import dao.CusDao;
import pojo.Customer;

public class Program {
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		try(CusDao cdao = new CusDao();)
		{
			int choice, cnum, rating;
			while((choice = menuList()) !=0 )
			{
				switch(choice)
				{
					case 1: Customer cus = new Customer();
							Program.acceptRecord(cus);
							cdao.insert(cus);
							break;
					case 2: System.out.print("Enetr customer id : ");
							cnum = sc.nextInt();
							System.out.print("Enter new Rating : ");
							rating = sc.nextInt();
							cdao.update(cnum, rating);
							break;
					case 3: System.out.print("Enetr cnum to delete the record : ");
							cnum = sc.nextInt();
							cdao.delete(cnum);
							break;
					case 4: List<Customer> cList = cdao.select();
							Program.printRecord(cList);
							break;
				}
			}
		} catch (IOException e) {
			
			e.printStackTrace();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}

	private static void printRecord(List<Customer> cList) {
		if(cList != null)
		{
			for(Customer cus : cList)
			{
				System.out.println(cus.toString());
			}
		}
		
	}

	private static void acceptRecord(Customer cus) {
		System.out.print("Enter Customer Number : ");
		cus.setCnum(sc.nextInt());
		sc.nextLine();
		System.out.print("Enter Customer Name : ");
		cus.setCname(sc.nextLine());
		System.out.print("Enter Customer City : ");
		cus.setCity(sc.nextLine());
		System.out.print("Enter Customer Rating : ");
		cus.setRating(sc.nextInt());
		System.out.print("Enter Customer Number : ");
		cus.setSnum(sc.nextInt());	
		
	}

	private static int menuList() {
		System.out.println("===========================");
		System.out.println("0. Exit");
		System.out.println("1. Insert");
		System.out.println("2. Update");
		System.out.println("3. Delete");
		System.out.println("4. Select");
		System.out.print(" Enetr Your Chhoice :");
		
		return sc.nextInt();
	}
}
