package dao;

import java.io.Closeable;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import pojo.Customer;
import utils.DButils;

public class CusDao implements Closeable {
	private Connection con;
	private PreparedStatement insertSt;
	private PreparedStatement updateSt;
	private PreparedStatement deleteSt;
	private PreparedStatement selectSt;
	
	public CusDao() throws Exception {
		con = DButils.getConnection();
		insertSt = con.prepareStatement("INSERT INTO CUSTOMERS VALUES(?,?,?,?,?)");
		updateSt = con.prepareStatement("UPDATE CUSTOMERS SET rating=? WHERE cnum=?");
		deleteSt = con.prepareStatement("DELETE FROM CUSTOMERS WHERE cnum=?");
		selectSt = con.prepareStatement("SELECT * FROM CUSTOMERS");
	}
	
	public int insert(Customer cus) throws Exception
	{
		insertSt.setInt(1, cus.getCnum());
		insertSt.setString(2, cus.getCname());
		insertSt.setString(3, cus.getCity());
		insertSt.setInt(4, cus.getRating());
		insertSt.setInt(5, cus.getSnum());
		return insertSt.executeUpdate();
		
	}
	
	public int update(int num, int rat) throws Exception
	{
		updateSt.setInt(1, rat);
		updateSt.setInt(2, num);
		return updateSt.executeUpdate();
	}
	
	public int delete(int num) throws Exception
	{
		deleteSt.setInt(1, num);
		return deleteSt.executeUpdate();
	}
	
	public List<Customer> select() throws Exception
	{
		List<Customer> cusList = new ArrayList<>();
		try(ResultSet rs = selectSt.executeQuery();)
		{
			while(rs.next())
			{
				Customer c = new Customer(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5));
				cusList.add(c);
			}
		}
		return cusList;
		
	}
	@Override
	public void close() throws IOException {
		try {
			insertSt.close();
			updateSt.close();
			deleteSt.close();
			selectSt.close();
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}
	
}
