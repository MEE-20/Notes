import java.util.Scanner;

class Scaninput
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("\n Name :");
        String name = sc.next();

        System.out.println("\n Emp id :");
        int id = sc.nextInt();

        System.out.println("\n Salary :");
        double sal = sc.nextDouble();

        System.out.printf("%-10s %-8d %-10.5f", name,id,sal);
    }
}